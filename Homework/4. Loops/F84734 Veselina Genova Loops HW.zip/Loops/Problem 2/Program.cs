﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int userInput;
            do
            {
                Console.WriteLine("Enter a positive number: ");
                userInput = Convert.ToInt32(Console.ReadLine());
            }
            while (userInput <= 0);

            for (int i = 1; i <= userInput; i++)
            {
                if ((i % 3 == 0) || (i % 7 == 0))
                {
                    continue;
                }
                else
                {
                    Console.Write(i + " ");
                }
            }
        }
    }
}
