﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int userInput;
            do
            {
                Console.WriteLine("Enter a positive number: ");
                userInput = Convert.ToInt32(Console.ReadLine());
            }
            while (userInput <= 0);

            for(int i = 1; i <=userInput; i++)
            {
                Console.Write(i + " ");
            }

        }
    }
}
