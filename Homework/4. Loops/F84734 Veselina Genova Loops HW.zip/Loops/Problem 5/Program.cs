﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //a positive integer number n (1 ≤ n ≤ 20)
            int n;

            do
            {
                Console.WriteLine("Enter a number (1 <= n <= 20): ");
                n = Convert.ToInt32(Console.ReadLine());
            }
            while (n < 1 || n > 20);

            for (int i = 0; i < n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    Console.Write(i + j + " ");
                }
                Console.WriteLine();
            }
        }
    }
}