﻿using System;

namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a positive integer ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= n; i++)
            {
                if (i % 3 != 0 && i % 7 != 7)
                {
                    Console.Write(i + " ");
                }
            }
            Console.WriteLine();
        }
    }
}