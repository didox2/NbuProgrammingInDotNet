﻿using System;

namespace Problem4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter integers n and k: ");
            double n = double.Parse(Console.ReadLine());
            double k = double.Parse(Console.ReadLine());
            if (1 < k && k < n && n < 100)
            {
                double Nint = 1;
                double Kint = 1;
                for (int i = 1; i <= n; i++)
                {
                    Nint *= i;
                    if (i <= k)
                    {
                        Kint *= 1;
                    }
                }
                Console.WriteLine("The result is : ", Nint / Kint);
            }
            else
            {
                Console.WriteLine("Invalid input!");
            }
        }
    }
}