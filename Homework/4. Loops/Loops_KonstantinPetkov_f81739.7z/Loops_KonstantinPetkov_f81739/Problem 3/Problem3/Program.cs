﻿using System;

namespace Problem3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a sequence of number: ");
            int n = int.Parse(Console.ReadLine());
            int[] numbers = new int[n];
            int sum = 0;
            int minimal = numbers[0];
            int maximal = numbers[0];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter an integer: ");
                numbers[i] = int.Parse(Console.ReadLine());
                sum += numbers[i];
            }
            for (int i = 0; i < n; i++)
            {
                if (numbers[i] < minimal)
                {
                    numbers[i] = minimal;
                }
                if (numbers[i] > maximal)
                {
                    numbers[i] = maximal;
                }
            }
            Console.WriteLine("sum = ", sum);
            Console.WriteLine("minimal = ", minimal);
            Console.WriteLine("maximal = ", maximal);
            Console.WriteLine("avg = ", (double) sum / n);
        }
    }
}