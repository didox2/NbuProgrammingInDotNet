﻿namespace Problem_4
{
    using System;
    using System.Numerics;

    class StartUp
    {
        /*
         Write a program that calculates n! / k! for given n and k (1 < k < n < 100). Use only one loop
         */
        static void Main()
        {
            BigInteger n = BigInteger.Parse(Console.ReadLine());
            BigInteger k = BigInteger.Parse(Console.ReadLine());
            BigInteger result = 1;

            while (n - k > 0)
            {
                result *= n;
                n--;
            }

            Console.WriteLine(result);
        }
    }
}
