﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5
{
    class Problem5
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter an integer in the range 1 to 20:");
            int n = int.Parse(Console.ReadLine());
            int countCol = 1;
            if (n < 1 || n > 20)
            {
                Console.WriteLine("Wrong number!");
                return;
            }
            for (int i = 1; i <= n; i++)
            {
                for (int j = i; j < 2 * n; j++)
                {
                    if (countCol <= n)
                    {
                        Console.Write("{0} ", j);
                        countCol++;
                    }
                }
                Console.WriteLine();
                countCol = 1;
            }
        }
    }
}
