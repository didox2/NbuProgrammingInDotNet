﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_4
{
    class Problem4
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two integers /n and k/ in range (1 < k < n < 100):");
            int n = int.Parse(Console.ReadLine());
            int k = int.Parse(Console.ReadLine());
            if (k <= 1 || k > n || n <= 1 || n >= 100 || k >= 100)
            {
                Console.WriteLine("Not valid numbers!");
                return;
            }
            int factorialN = 1;
            int factorialK = 1;
            for (int i = 1; i <= n; i++)
            {
                factorialN *= i;
                if (i <= k)
                {
                    factorialK *= i;
                }
            }
            Console.WriteLine("{0}", factorialN / factorialK);
        }
    }
}
