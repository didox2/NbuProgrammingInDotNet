﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2
{
    class Problem2
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter a number: ");
            bool notInt = int.TryParse(Console.ReadLine(), out n);
            if (notInt)
            {
                for (int i = 1; i <= n; i++)
                {
                    if (i % 3 != 0 && i % 7 != 0)
                    {
                        Console.Write("{0} ", i);
                    }
                }
            }
            else
            {
                Console.WriteLine("Not a valid integer number!");
            }
            Console.ReadKey();
        }
    }
}
