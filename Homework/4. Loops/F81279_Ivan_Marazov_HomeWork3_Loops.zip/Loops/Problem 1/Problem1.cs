﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1
{
    class Problem1
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("Enter number: ");
            bool notInt = int.TryParse(Console.ReadLine(), out n);
            if(notInt)
            {
                for (int i = 1; i <= n; i++)
                {
                    Console.Write("{0} ", i);
                }
            }
            else
            {
                Console.WriteLine("Please write a valid integer number!");
            }
            Console.ReadKey();
        }
    }
}
