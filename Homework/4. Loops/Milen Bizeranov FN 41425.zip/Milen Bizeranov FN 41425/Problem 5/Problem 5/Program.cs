﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5
{
    class MatrixOfNumbers
    {
        static void Main()
        {
            Console.WriteLine("Enter an integer number from 1 to 20:");
            int n = int.Parse(Console.ReadLine());
            int c = 1;
            if (n < 1 || n > 20)
            {
                Console.WriteLine("Invalid range!");
                return;
            }
            for (int i = 1; i <= n; i++)
            {
                for (int j = i; j < 2 * n; j++)
                {
                    if (c <= n)
                    {
                        Console.Write("{0} ", j);
                        c++;
                    }
                }
                Console.WriteLine();
                c = 1;

            }
            Console.ReadKey();
        }
    }
}