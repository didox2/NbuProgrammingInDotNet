﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Problem_4
{
    static void Main()
    {
        Console.WriteLine("Enter a value for N");
        int n = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter a value for K (1 < K < N )");
        int k = int.Parse(Console.ReadLine());
        double nF = 1;
        double kF = 1;
        for (int i = n; i > 0; i--)
        {
            nF *= i;
        }
        for (int j = k; j > 0; j--)
        {
            kF *= j;
        }
        double result = nF / kF;
        Console.WriteLine("N!/K! = {0}", result);
        Console.ReadKey();
    }
   
}
