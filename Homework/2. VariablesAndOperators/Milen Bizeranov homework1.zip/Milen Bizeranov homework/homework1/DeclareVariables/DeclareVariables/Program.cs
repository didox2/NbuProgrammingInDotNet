﻿using System;

class DeclareVariables
{
    static void Main()
    {
        ushort a = 52130;
        sbyte b = -115;
        int c = 4825932;
        byte d = 97;
        short e = -10000;
        Console.WriteLine("a: type = {0}; value = {1}", a.GetTypeCode(), a);
        Console.WriteLine("b: type = {0}; value = {1}", b.GetTypeCode(), b);
        Console.WriteLine("c: type = {0}; value = {1}", c.GetTypeCode(), c);
        Console.WriteLine("d: type = {0}; value = {1}", d.GetTypeCode(), d);
        Console.WriteLine("e: type = {0}; value = {1}", e.GetTypeCode(), e);
        Console.ReadKey();
    }
}
