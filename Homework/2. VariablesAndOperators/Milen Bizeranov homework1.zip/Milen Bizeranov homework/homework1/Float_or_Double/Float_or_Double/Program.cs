﻿using System;

class Float_or_Double
{
    static void Main()
    {
        double a = 34.567839023d;
        float b = 12.345f;
        double c = 8923.1234857d;
        float d = 3456.091f;

        Console.WriteLine("a: type = {0}; value = {1}", a.GetTypeCode(), a);
        Console.WriteLine("b: type = {0}; value = {1}", b.GetTypeCode(), b);
        Console.WriteLine("c: type = {0}; value = {1}", c.GetTypeCode(), c);
        Console.WriteLine("d: type = {0}; value = {1}", d.GetTypeCode(), d);
        Console.ReadKey();
    }
}

