﻿
using System;

class BooleanVariable
{
    static void Main(string[] args)
    {
        bool isFemale = false;
        Console.WriteLine(isFemale);
        Console.ReadKey();
    }
}

