﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


class EmployeeData
{
    static void Main(string[] args)
    {
        Console.Write("Enter your first name: ");
        string firstName = Console.ReadLine();
        Console.Write("Enter your last name: ");
        string lastName = Console.ReadLine();
        Console.Write("Enter your age: ");
        byte age = byte.Parse(Console.ReadLine());
        Console.Write("Enter your gender (m/f): ");
        char gender = char.Parse(Console.ReadLine());
        Console.Write("Enter your personal ID: ");
        long personalID = long.Parse(Console.ReadLine());
        Console.Write("Enter your Unique Employee Number: ");
        int uniqueEmployeeNumber = int.Parse(Console.ReadLine());

        Console.WriteLine("First name: {0}\nLast name: {1}\nAge: {3}\nGender: {4}\nPersonal ID: {5}\nUniqueEmployeeNumber: {6}",
            firstName, lastName, age, gender, personalID, uniqueEmployeeNumber);
        Console.ReadKey();

    }
}




