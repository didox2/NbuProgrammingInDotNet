﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2.Float_or_Double
{
    class Program
    {
        static void Main(string[] args)
        {
            double variableDoubeOne = 34.567839023;
            float variableFloatOne = 12.345F;
            double variableDoubleTwo = 8923.1234857;
            float variableFloatThree = 3456.091F;
            Console.WriteLine(variableDoubeOne + "\r\n" + variableFloatOne + "\r\n" + variableDoubleTwo + "\r\n" + variableFloatThree);

        }
    }
}
