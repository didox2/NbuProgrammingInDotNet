﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5.Employee_Data
{
    class Program
    {
        static void Main(string[] args)
        {
            string employeeFirstName = "Maria";
            string employeeLastName = "Georgieva";
            byte age = 57;
            char gender = 'f';
            ulong personalID = 8306112507;
            uint uniqueEmployeeID = 27569999;

            Console.WriteLine("Employee Data" + "\r\n" + "\r\n" + "First Name: " + employeeFirstName + "\r\n" + "Last Name: " + employeeLastName + "\r\n" + "Age: " + age + 
            "\r\n" + "Gender: " + gender + "\r\n" + "Personal ID Number: " + personalID + "\r\n" + "Unique Employee Number: " + uniqueEmployeeID);
        }
    }
}
