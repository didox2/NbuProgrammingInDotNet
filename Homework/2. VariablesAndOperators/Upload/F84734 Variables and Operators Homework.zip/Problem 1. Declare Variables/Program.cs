﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1.Declare_Variables
{
    class Program
    {
        static void Main(string[] args)
        {
            ushort variableOne = 52130;
            sbyte variableTwo = -115;
            uint variableThree = 4825932;
            byte variableFour = 97;
            short variableFive = -10000;
        }
    }
}
