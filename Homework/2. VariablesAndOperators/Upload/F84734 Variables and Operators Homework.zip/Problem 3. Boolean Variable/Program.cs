﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3.Boolean_Variable
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isFemale = true;
            Console.WriteLine(isFemale);
        }
    }
}
