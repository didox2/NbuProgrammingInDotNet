﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
    class VariablesAndOperators
    {
        
        static void Main(string[] args)
        {
            //Problem 1
            ushort a = 52130;
            sbyte b = -115;
            int c = 4825932;
            byte d = 97;
            short e = -10000;
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(d);
            Console.WriteLine(e);
            Console.WriteLine();
            //Problem 2
            double a1 = 34.567839023;
            float b1 = 12.345F;
            float c1 = 8923.1234857F;
            float d1 = 3456.091F;
            Console.WriteLine(a1);
            Console.WriteLine(b1);
            Console.WriteLine(c1);
            Console.WriteLine(d1);
            Console.WriteLine();
            //Problem 3
            bool isFemale = false;
            Console.WriteLine(isFemale);
            Console.WriteLine();

            //Problem 4
            string strHello = "Hello ";
            string strWorld = "World";
            object o = strHello + strWorld;
            Console.WriteLine(o);
            string strObj = o.ToString();
            Console.WriteLine(strObj);
            Console.WriteLine();

            //Problem 5
            string firstName = "Kristiyan";
            string lastName = "Stefanov";
            byte age = 24;
            bool isMale = true;
            Int64 personalID = 8306112507;
            int uniqueID = 27569999;
            Console.WriteLine("Employee First name: "+ firstName);
            Console.WriteLine("Employee Last name: " + lastName);
            Console.WriteLine("Employee age: " + age);
            Console.WriteLine("Employee is male: " + isMale);
            Console.WriteLine("Employee personal ID: " + personalID);
            Console.WriteLine("Employee Unique ID: " + uniqueID);
        }
    }
}
