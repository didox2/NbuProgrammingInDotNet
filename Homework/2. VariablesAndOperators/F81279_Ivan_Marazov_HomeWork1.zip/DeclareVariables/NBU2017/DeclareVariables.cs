﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBU2017
{
    class DeclareVariables
    {
        static void Main()
        {
            ushort a = 52130;
            sbyte b = -115;
            int c = 4825932;
            byte d = 97;
            short e = -10000;

            Console.WriteLine("ushort type = {0}; value = {1}", a.GetTypeCode(), a);
            Console.WriteLine("sbyte type = {0}; value = {1}", b.GetTypeCode(), b);
            Console.WriteLine("int type = {0}; value = {1}", c.GetTypeCode(), c);
            Console.WriteLine("byte type = {0}; value = {1}", d.GetTypeCode(), d);
            Console.WriteLine("short type = {0}; value = {1}", e.GetTypeCode(), e);         
        }
    }
}
