﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBU2017
{
    class EmployeeData
    {
        static void Main(string[] args)
        {
            string fName;
            string lName;
            byte age;
            char gender;
            long id;
            int enr;

            Console.Write("First name: ");
            fName = Console.ReadLine();

            Console.Write("Last name: ");
            lName = Console.ReadLine();

            Console.Write("Age: ");
            age = byte.Parse(Console.ReadLine());

            Console.Write("Gender: ");
            gender = char.Parse(Console.ReadLine());

            Console.Write("Personal ID Number: ");
            id = long.Parse(Console.ReadLine());

            Console.Write("Unique employee number: ");
            enr = int.Parse(Console.ReadLine());

            Console.ReadKey();
            Console.WriteLine(fName);
            Console.WriteLine(lName);
            Console.WriteLine(age);
            Console.WriteLine(gender);
            Console.WriteLine(id);
            Console.WriteLine(enr);

        }
    }
}
