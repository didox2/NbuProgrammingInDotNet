﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooleanVariable
{
    class BooleanVariable
    {
        static void Main()
        {
            bool isFemale = false;
            Console.WriteLine(isFemale);
        }
    }
}
