﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FloatOrDouble
{
    class FloatOrDouble
    {
        static void Main()
        {
            double x = 34.567839023D;
            float y = 12.345F;
            double z = 8923.1234857D;
            float w = 3456.091F;

            double x1 = x * 2;
            float y1 = y * 2;
            double z1 = z * 2;
            float w1 = w * 2;

            Console.WriteLine("double type = {0}; value = {1}", x.GetTypeCode(), x);
            Console.WriteLine("double type = {0}; value = {1}", x1.GetTypeCode(), x1);

            Console.WriteLine("float type = {0}; value = {1}", y.GetTypeCode(), y);
            Console.WriteLine("float type = {0}; value = {1}", y1.GetTypeCode(), y1);

            Console.WriteLine("double type = {0}; value = {1}", z.GetTypeCode(), z);
            Console.WriteLine("double type = {0}; value = {1}", z1.GetTypeCode(), z1);

            Console.WriteLine("float type = {0}; value = {1}", w.GetTypeCode(), w);
            Console.WriteLine("float type = {0}; value = {1}", w1.GetTypeCode(), w1);

        }
    }
}
