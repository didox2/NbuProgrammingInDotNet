﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringsAndObjects
{
    class StringsAndObjects
    {
        static void Main()
        {
            string a = "Hello";
            string b = "world!";
            object c = a + " " + b;
            Console.WriteLine(c);

            string d = (string)c; 
            Console.WriteLine(d);

        }
    }
}
