﻿namespace Problem_5.Employee_Data
{
    using System;
    class StartUp
    {
        /*
         Problem 5.	Employee Data

          A marketing company wants to keep record of its employees. Each record would have the following characteristics:
         •	First name
         •	Last name
         •	Age (0...100)
         •	Gender (m or f)
         •	Personal ID number (e.g. 8306112507)
         •	Unique employee number (27560000…27569999)
       
         Declare the variables needed to keep the information for a single employee using appropriate primitive data types. 
         Use descriptive names. Print the data at the console.
       
         HINT: Use Console.Write and Console.WriteLine to output data to the console
         */
        static void Main()
        {
            string fName = "Ditmar";
            string lName = "Vladislavov";
            byte age = 25;
            char gender = 'm';
            long pesonalID = 8306112507;
            int uniqueEmployeeNumber = 27560000;

            Console.WriteLine($"First name: {fName}");
            Console.WriteLine($"Last name: {lName}");
            Console.WriteLine($"Age: {age}");
            Console.WriteLine($"Gender (\"m\" or \"f\"): {gender}");
            Console.WriteLine($"Personal ID number: {pesonalID}");
            Console.WriteLine($"Unique employee number: {uniqueEmployeeNumber}");
        }
    }
}
