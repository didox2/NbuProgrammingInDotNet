﻿namespace Problem_3.Boolean_Variable
{
    using System;
    class StartUp
    {
        /*
        Problem 3.	Boolean Variable

         Declare a Boolean variable called isFemale and assign an appropriate value corresponding to your gender. Print it on the 
        console.
        */
        static void Main()
        {
            bool isFemale = false;

            Console.WriteLine($"Are you Female: {isFemale}");
        }
    }
}
