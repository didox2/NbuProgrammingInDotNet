﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int I = 52130;
            short u = -115;
            long t = 4825932;
            short s = 97;
            int o = -10000;

            //Problem 2 
            Double d = 34.567839023;
            float f = 12.345f;
            Double d2 = 8923.1234857;
            float f2 = 3456.091f; 
            Console.WriteLine(d + " is double"+" and so is "+d2 +", but "+f +" is float and so is "+f2);
            Console.WriteLine();
            //Problem 3
            bool isFemale = false;
            Console.WriteLine("I am Plamen and I’m male, therefore the value of my isFemale variable is: "+isFemale);
            Console.WriteLine();
            //Problem 4
            String hello = "Hello";
            String world = "World";
            Object hW = (Object)hello + " " +(Object)world;
            Console.WriteLine(hW);
            Console.WriteLine();
            Console.WriteLine();
            //Problem 5
            Console.WriteLine("Write the first name of the employee:");
            String fName = Console.ReadLine();
            Console.WriteLine("Write the last name of the employee:");
            String lName = Console.ReadLine();
            Console.WriteLine("Write the age(0 to 100) of the employee (p.s. and yes I know if you have entered a number outside the given scopes):");
            int age = Convert.ToInt32(Console.ReadLine());
                  
            Console.WriteLine("Write the gender of the employee(‘m’ for male or ‘f’ for female)(p.s. yes I know if you enter something else as answer):") ;
            char gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Write the ID  of the employee(0 to 4,294,967,295):");
            uint id = Convert.ToUInt32(Console.ReadLine());
            Console.WriteLine("Write the unique Number of the employee (can use numbers and letters): ");
            String uniqueN = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("First name: " + fName);
            Console.WriteLine("Last Name: "+lName);
            if (age > 100)
            {
                Console.WriteLine("The employee is a rotten vegetable above 100 years");
            }
            else if (age < 0)
            {
                Console.WriteLine("The employee is still a thought in his parents brains");
            }
            else
            {
                Console.WriteLine("Age: " + age);
            }
            if (gender == 'm')
            {
                Console.WriteLine("Gender: male");
            } else if (gender =='f')
            {
                Console.WriteLine("Gender: female");
            } else
            {
                Console.WriteLine("You have entered wrong gender, therefore the employee is specified as THIRD GENDER, haha");
            }
            Console.WriteLine("ID: "+id);
            Console.WriteLine("Unique Numbe: "+uniqueN);
            Console.ReadLine();

        }
    }
}
