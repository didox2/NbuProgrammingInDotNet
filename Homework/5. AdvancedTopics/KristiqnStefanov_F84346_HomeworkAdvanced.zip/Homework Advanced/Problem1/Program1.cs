﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace Problem1
{
    class Program1
    //Write a program that enters two dates in format dd.MM.yyyy and returns the number of days between them.
    {
        static void Main(string[] args)
        {
            string fDate = Console.ReadLine();
            string lDate = Console.ReadLine();
            string dateFormat = "d.MM.yyyy";
            DateTime firstDate = DateTime.ParseExact(fDate, dateFormat,
            CultureInfo.InvariantCulture);
            DateTime secondDate = DateTime.ParseExact(lDate, dateFormat,
            CultureInfo.InvariantCulture);
            int difference = CalculateNumberDifferenceDates(firstDate, secondDate);
            Console.WriteLine("Days between: {0} ", difference);
        }
        private static int CalculateNumberDifferenceDates(DateTime firstDate, DateTime secondDate)
        {
            // Difference in days, hours, and minutes.
            TimeSpan ts = secondDate - firstDate;
            // Difference in days.
            int differenceInDays = ts.Days;
            return differenceInDays;
        }
    }
}
