﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem4
{
    class Program4
    //Write a program to find the longest word in a text
    {
        static void Main(string[] args)
        {
            string[] word = Console.ReadLine().Split(new char[] { ',', ';', ' ', '-', '.' },
        StringSplitOptions.RemoveEmptyEntries);
            string longestWord = word[0];
            for (int i = 0; i < word.Length; i++)
            {
                if (longestWord.Length > word[i].Length)
                {
                    continue;
                }
                else
                {
                    longestWord = word[i];
                }
            }
            Console.WriteLine(longestWord);
        }
    }
}
