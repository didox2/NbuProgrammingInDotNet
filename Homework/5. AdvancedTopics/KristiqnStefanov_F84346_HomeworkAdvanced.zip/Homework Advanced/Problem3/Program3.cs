﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem3
{
    class Program3
    //Write a program that takes as input two lists of names and removes from the first list all names given in the second list

    {
        static void Main(string[] args)
        {
            List<string> listOne = new List<string>();
            string[] fNames = Console.ReadLine().Split();
            for (int i = 0; i < fNames.Length; i++)
            {
                listOne.Add(fNames[i]);
            }
            List<string> listTwo = new List<string>();
            string[] sNames = Console.ReadLine().Split();
            for (int i = 0; i < sNames.Length; i++)
            {
                listTwo.Add(sNames[i]);
            }
            List<string> listNames = new List<string>();
            foreach (var item in listOne)
            {
                if (listTwo.Contains(item))
                {
                    continue;
                }
                else
                {
                    listNames.Add(item);
                }
            }
            foreach (var item in listNames)
            {
                Console.Write("{0} ", item);
            }
            Console.WriteLine();
        }
    }
}
