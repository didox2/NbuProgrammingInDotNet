﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem5
{
    class Program5
        //Write a program that reads from the console a sequence of n integer numbers and returns the minimal, the maximal 
        //number, the sum and the average of all numbers(displayed with 2 digits after the decimal point). The input starts by
        //the number n(alone in a line) followed by n lines, each holding an integer number.DO NOT USE LOOPS FOR CALCULATIONS!!!
    {
        static void Main(string[] args)
        {
            Console.Write("Enter n numbers:");
            int n = int.Parse(Console.ReadLine());
            double[] numArr = new double[n];
            double[] secondArr = numArr;
            for (int i = 0; i < n; i++)
            {
                numArr[i] = double.Parse(Console.ReadLine());
            }
            Console.WriteLine("The minimal number is: "+ numArr.Min());
            Console.WriteLine("The maximal number is: " + numArr.Max());
            Console.WriteLine("The sum of the numbers is: " + secondArr.Sum());
            Console.WriteLine("The averege number is: "+ numArr.Average());
        }
    }
}
