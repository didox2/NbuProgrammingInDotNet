﻿using System;

namespace Problem_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            int[] SortNumbers(int count)
            {
                int[] arrNumb = new int[count];
                for (int i = 0; i < count; i++)
                {
                    arrNumb[i] = int.Parse(Console.ReadLine());
                }
                Array.Sort(arrNumb);
                return arrNumb;
            }

            int[] sortArr = SortNumbers(n);

            for (int i = 0; i < sortArr.Length; i++)
            {
                Console.Write(sortArr[i] + " ");
            }
            Console.WriteLine();
        }
    }
}