﻿using System;

namespace problem_1
{
    class Program
    {        

        static void Main(string[] args)
        {
            DateTime fDate = DateTime.Parse(Console.ReadLine());
            DateTime sDate = DateTime.Parse(Console.ReadLine());

            Console.WriteLine("Number of days between: {0}", CountOfDays(fDate, sDate));
        }

        static double CountOfDays(DateTime sDate, DateTime eDate)
        {
            TimeSpan daysBetweenDates = eDate - sDate;
            double result = daysBetweenDates.TotalDays;
            return result;
        }
    }
}