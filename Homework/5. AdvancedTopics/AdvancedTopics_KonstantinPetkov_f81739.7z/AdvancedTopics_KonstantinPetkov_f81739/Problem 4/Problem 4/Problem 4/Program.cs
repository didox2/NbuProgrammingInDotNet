﻿using System;

namespace Problem_4
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] w = input.Split(new char[] { ' ', '.', ',' }, StringSplitOptions.RemoveEmptyEntries);

            int longestWord = 0;
            string word = null;

            for (int i = 0; i < w.Length; i++)
            {
                if (w[i].Length > longestWord)
                {
                    word = w[i];
                    longestWord = w[i].Length;
                }
            }
            Console.WriteLine(word);
        }
    }
}