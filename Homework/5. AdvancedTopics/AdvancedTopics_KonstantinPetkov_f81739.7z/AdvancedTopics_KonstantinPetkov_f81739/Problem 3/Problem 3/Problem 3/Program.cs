﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Problem_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputName = Console.ReadLine();
            List<string> firstListName = inputName.Split(' ').ToList();

            string nameRemoved = Console.ReadLine();
            List<string> secondListName = nameRemoved.Split(' ').ToList();

            for (int i = 0; i < secondListName.Count; i++)
            {
                for (int j = 0; j < firstListName.Count; j++)
                {
                    if (firstListName.Contains(secondListName[i]))
                    {
                        firstListName.Remove(secondListName[i]);
                    }
                }
            }

            foreach (var name in firstListName)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine(string.Join<string>(" ", firstListName));
        }
    }
}