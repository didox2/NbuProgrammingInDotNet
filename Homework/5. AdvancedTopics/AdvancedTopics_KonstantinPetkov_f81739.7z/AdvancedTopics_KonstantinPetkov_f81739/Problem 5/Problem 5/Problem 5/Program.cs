﻿using System;
using System.Linq;

namespace Problem_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number sequence: ");
            int n = int.Parse(Console.ReadLine());
            double[] array = new double[n];

            for (int i = 0; i < n; i++)
            {
                Console.Write("{0} integer: ", i);
                array[i] = double.Parse(Console.ReadLine());
            }

            Console.WriteLine("min = {0}", array.Min());
            Console.WriteLine("max = {0}", array.Max());
            Console.WriteLine("sum = {0}", array.Sum());
            Console.WriteLine("avg = {0:F2}", array.Average());
    }
    }
}