﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2

{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter number N: ");
            int n = Convert.ToInt32(Console.ReadLine());
            List<int> list = new List<int>();
            int number = 1;
            for (int i=0; i<n; i++ )
            {
                Console.Write("Enter number " + number + ": ");
                number++;
                list.Add(Convert.ToInt32(Console.ReadLine()));
            }
            list.Sort();
            Console.WriteLine("Your numbers sorted are:");
            foreach (int item in list)
            {
                Console.WriteLine(item);
            }
        }
    }
}
