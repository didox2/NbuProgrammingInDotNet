﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Choose how many numbers you want to put in your collection:");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[n];
            int number = 1;
            for (int i=0; i<n; i++)
            {
                Console.Write("Add number " + number + ":");
                array[i] = Convert.ToInt32(Console.ReadLine());
                number++;
            }
            Console.WriteLine("Your minimal number is: " + array.Min());
            Console.WriteLine("Your maximal number is: " + array.Max());
            Console.WriteLine("Your average of all numbers: " + array.Average());
            Console.WriteLine("Your sum of all numbers: " + array.Sum());
        }
    }
}
