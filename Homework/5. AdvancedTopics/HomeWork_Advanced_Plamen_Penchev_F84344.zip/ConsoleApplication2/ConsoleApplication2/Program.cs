﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1

{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write 2 dates in dd-MM-yyyy format:");
            Console.Write("Date 1: ");
            String date1 = Console.ReadLine();
            Console.Write("Date 2: ");
            String date2 = Console.ReadLine();
            TimeSpan ts = DateTime.ParseExact(date2, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture)
                  - DateTime.ParseExact(date1, "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
            Console.WriteLine("There are " + ts.Days + " Days between " + date1 + " and " + date2 + ".");


        }
        
    }
}
