﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write a text:");
            String[] words = Console.ReadLine().Split(new char[] { ',', ';', ' ', '-', '.' },StringSplitOptions.RemoveEmptyEntries);
            String longWord = words[0];
            
            for (int i = 0; i < words.Length; i++)
            {
                if (longWord.Length > words[i].Length)
                {
                    continue;
                }
                else
                {
                    longWord = words[i];
                }
            }
            Console.WriteLine("Your longest word in the text you've written is: "+ longWord);
        }
    }
}
