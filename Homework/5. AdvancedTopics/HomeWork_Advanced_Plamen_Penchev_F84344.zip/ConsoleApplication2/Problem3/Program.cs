﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<String> firstList = new List<String>();
            Console.Write("Choose how many names you want to add in your first list:");
            int n = Convert.ToInt32(Console.ReadLine());
            int numbers = 1;
            for (int i=0; i<n; i++)
            {
                Console.Write("Add name " + numbers + ": ");
                numbers++;
                firstList.Add(Console.ReadLine());
            }
            List<String> secondList = new List<String>();
            Console.Write("Choose how many names you want to add in your second list:");
            int n2 = Convert.ToInt32(Console.ReadLine());
            int numbers2 = 1;
            for (int i = 0; i < n2; i++)
            {
                Console.Write("Add name " + numbers2 + ": ");
                numbers++;
                secondList.Add(Console.ReadLine());
            }
            Console.WriteLine("Your first list looks like this now:");
            foreach (String item in firstList)
            {
                Console.WriteLine(item);
            }
                Console.WriteLine("If you have names from the first list which equal the ones from the second, they will be removed.");
            foreach (String item in secondList){
                if (firstList.Contains(item))
                {
                    firstList.Remove(item);
                }
            }
            Console.WriteLine("Your first list after second list comparison:");
            foreach (String item in firstList)
            {
                Console.WriteLine(item);
            }
        }
    }
}
