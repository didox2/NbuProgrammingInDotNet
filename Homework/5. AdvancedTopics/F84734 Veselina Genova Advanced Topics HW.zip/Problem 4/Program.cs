﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program to find the longest word in a text
            var fileText = File.ReadAllText(@"C:\Users\veselina\Desktop\Problem4.txt");
            string[] stringOfWords = fileText.Split(' ');

            Console.WriteLine("Whole Text: " + fileText);
            Console.WriteLine("Number of words in the text: " + fileText.Split(' ').Length);

            var finalValue = stringOfWords.OrderByDescending(n => n.Length).First();

            Console.WriteLine("Longest word is: " + finalValue);
        }
    }
}
