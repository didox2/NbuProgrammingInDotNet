﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that reads a number n and a sequence of n integers, sorts them and prints them.

            Console.WriteLine("Enter a number sequence: ");
            int sequenceNumber = Convert.ToInt32(Console.ReadLine());
            double[] sequence = new double[sequenceNumber];

            for (int i = 0; i < sequenceNumber; i++)
            {
                Console.Write("{0} number: ", i+ 1);
                sequence[i] = Convert.ToDouble(Console.ReadLine());
            }

            Array.Sort(sequence);

            foreach (double number in sequence)
            {
                Console.Write(number);
                Console.Write(' ');
            }
            Console.WriteLine();
        }
    }
}
