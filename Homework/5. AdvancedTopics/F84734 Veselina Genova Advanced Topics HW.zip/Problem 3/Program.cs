﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that takes as input two lists of names and removes from the first list all names given in the second list

            Console.WriteLine("Enter the first list of names: ");
            List<string> listOne = new List<string>();
            string[] namesOne = Console.ReadLine().Split();
            for (int i = 0; i < namesOne.Length; i++)
            {
                listOne.Add(namesOne[i]);
            }
            Console.WriteLine("Enter the names to be removed: ");
            List<string> listTwo = new List<string>();
            string[] namesTwo = Console.ReadLine().Split();
            for (int i = 0; i < namesTwo.Length; i++)
            {
                listTwo.Add(namesTwo[i]);
            }
            List<string> newNames = new List<string>();
            foreach (String name in listOne)
            {
                if (listTwo.Contains(name))
                {
                    continue;
                }
                else
                {
                    newNames.Add(name);
                }
            }
            Console.WriteLine("The names left are: ");
            foreach (String name in newNames)
            {
                Console.Write("{0} ", name);
            }
            Console.WriteLine();
        }
    }
}
