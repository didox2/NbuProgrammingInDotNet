﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number sequence ");
            int seqNumber = Convert.ToInt32(Console.ReadLine());
            double[] sequence = new double[seqNumber];

            for (int i = 0; i < seqNumber; i++)
            {
                Console.Write("{0}.integer: ", i);
                sequence[i] = Convert.ToDouble(Console.ReadLine());
            }

            Console.WriteLine("Minimal number is: " + sequence.Min());
            Console.WriteLine("Maximal number is: " + sequence.Max());
            Console.WriteLine("The Sum is: " + sequence.Sum());
            Console.WriteLine("The Average number is: " + "{0:F2}", sequence.Average());
        }
    }
}
