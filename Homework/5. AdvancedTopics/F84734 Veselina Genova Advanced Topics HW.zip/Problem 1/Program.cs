﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace Problem_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program that enters two dates in format dd.MM.yyyy and returns the number of days between them.

            string format = "dd.MM.yyyy";
            Console.WriteLine("Enter a date: ");
            string dateStringOne = Console.ReadLine();
            Console.WriteLine("Enter another date: ");
            string dateStringTwo = Console.ReadLine();
            DateTime dateOne = DateTime.ParseExact(dateStringOne, format, CultureInfo.InvariantCulture);
            DateTime dateTwo = DateTime.ParseExact(dateStringTwo, format, CultureInfo.InvariantCulture);

            TimeSpan t = dateTwo - dateOne;
            double numberOfDays = t.TotalDays;
            Console.WriteLine("The number of days between the two dates is: " + numberOfDays);
        }
    }
}
