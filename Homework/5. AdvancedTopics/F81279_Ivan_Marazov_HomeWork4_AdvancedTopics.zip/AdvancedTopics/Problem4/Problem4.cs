﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem4
{
    class Problem4
    {
        static void Main()
        {
            Console.WriteLine("Please enter some text in a few words: ");
            string inputText = Console.ReadLine();
            string[] allWords = inputText.Split(new char[] { ' ', '.' }, StringSplitOptions.RemoveEmptyEntries);

            int longestWordSize = 0;
            string longestWord = null;

            for (int i = 0; i < allWords.Length; i++)
            {
                if (allWords[i].Length > longestWordSize)
                {
                    longestWord = allWords[i];
                    longestWordSize = allWords[i].Length;
                }
            }
            Console.WriteLine("This is the longest of your words in text: ");
            Console.WriteLine(longestWord);
        }
    }
}
