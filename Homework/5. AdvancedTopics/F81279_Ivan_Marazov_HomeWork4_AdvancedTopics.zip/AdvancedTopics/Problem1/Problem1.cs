﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    class Problem1
    {
        static void Main(string[] args)
        {
            DateTime firstDate;
            DateTime secondDate;
            Console.Write("Enter First Date: ");
            firstDate = DateTime.Parse(Console.ReadLine());
            Console.WriteLine(firstDate);
            Console.Write("Enter Second Date: ");
            secondDate = DateTime.Parse(Console.ReadLine());
            Console.WriteLine(secondDate);
            Console.WriteLine("Days between dates is: " + (secondDate - firstDate).TotalDays);
        }
    }
}
