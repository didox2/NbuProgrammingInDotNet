﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2
{
    class Problem2
    {
        static void Main()
        {
            Console.WriteLine("Enter a number for a size of a list you wish to order:");
            int n = int.Parse(Console.ReadLine());
            List<int> numbers = new List<int>();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter the a number into the list: ");
                int num = int.Parse(Console.ReadLine());
                numbers.Add(num);
            }
            numbers.Sort();
            Console.WriteLine();
            Console.WriteLine("Your list looks like this:");
            foreach (var item in numbers)
            {
                Console.WriteLine("{0}", item);
            }
        }
    }
}
