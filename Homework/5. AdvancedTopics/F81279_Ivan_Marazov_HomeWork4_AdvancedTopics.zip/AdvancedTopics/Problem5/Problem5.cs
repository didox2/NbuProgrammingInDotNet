﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem5
{
    class Problem5
    {
        static void Main()
        {
            Console.WriteLine("Enter a number for the size of the list:");
            int n = int.Parse(Console.ReadLine());
            int[] array = new int[n];

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Enter the numbers in the list: ");
                array[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("min = {0}", array.Min());
            Console.WriteLine("max = {0}", array.Max());
            Console.WriteLine("sum = {0}", array.Sum());
            Console.WriteLine("avg = {0:F2}", array.Average());
        }
    }
}
