﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem3
{
    class Problem3
    {
        static void Main()
        {
            Console.WriteLine("Enter some names for the first list separated by space:");
            string input = Console.ReadLine();
            List<string> names = input.Split(' ').ToList();
            Console.WriteLine("Enter the names in the second list:");
            string namesToBeRemoved = Console.ReadLine();
            List<string> equalNames = namesToBeRemoved.Split(' ').ToList();

            
            for (int i = 0; i < equalNames.Count; i++) // The length of this list is constant
            {
                for (int j = 0; j < names.Count; j++)
                {
                    if (names.Contains(equalNames[i]))
                    {
                        names.Remove(equalNames[i]);
                    }
                }
            }
            foreach (var name in names)
            {
                Console.WriteLine("you have the following unique names from the first list:");
                Console.WriteLine(name);
            }
        }
    }
}
