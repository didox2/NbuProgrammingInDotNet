﻿namespace Problem_4
{
    using System;
    class StartUp
    {
        // Write a program to find the longest word in a text
        static void Main()
        {
            string text = Console.ReadLine();
            string[] separators = { ",", ".", "!", "?", ";", ":", " " };
            string[] words = text.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            int longest = 0;
            string longestWord = "";
            foreach (var word in words)
            {
                if (word.Length >= longest)
                {
                    longest = word.Length;
                    longestWord = word;
                }
            }
            Console.WriteLine($"The longest word in the text is: \"{longestWord}\" - length = {longestWord.Length} chars");
        }
    }
}
