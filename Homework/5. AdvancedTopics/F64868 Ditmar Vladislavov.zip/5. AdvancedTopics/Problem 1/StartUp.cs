﻿namespace Problem_1
{
    using System;
    class StartUp
    {
        // Write a program that enters two dates in format dd.MM.yyyy and returns the number of days between them.
        static void Main()
        {
            string dateString1 = Console.ReadLine();
            string dateString2 = Console.ReadLine();

            DateTime firstDate;
            if (!DateTime.TryParse(dateString1, out firstDate))
            {
                Console.WriteLine("Invalid first date!");
            }

            DateTime secondDate;
            if (!DateTime.TryParse(dateString2, out secondDate))
            {
                Console.WriteLine("Invalid second date!");
            }

            Console.WriteLine(Math.Abs((firstDate - secondDate).TotalDays)); 
        }
    }
}
