﻿namespace Problem_5
{
    using System;
    class StartUp
    {
        /*
         Write a program that reads from the console a sequence of n integer numbers and returns the minimal, the maximal 
         number, the sum and the average of all numbers (displayed with 2 digits after the decimal point). The input starts by 
         the number n (alone in a line) followed by n lines, each holding an integer number. DO NOT USE LOOPS FOR CALCULATIONS!!!
         */
        static void Main()
        {
            double input = double.Parse(Console.ReadLine());
            double sum = 0;
            double max = double.MinValue;
            double min = double.MaxValue;
            double temp = 0;
            for (double i = 0; i < input; i++)
            {
                temp = double.Parse(Console.ReadLine());
                sum += temp;
                if (temp < min)
                {
                    min = temp;
                }
                if (temp > max)
                {
                    max = temp;
                }
            }
            double avg = sum / input;
            Console.WriteLine($"MIN = {min:F2}");
            Console.WriteLine($"MAX = {max:F2}");
            Console.WriteLine($"SUM = {sum:F2}");
            Console.WriteLine($"AVG = {avg:F2}");
        }
    }
}
