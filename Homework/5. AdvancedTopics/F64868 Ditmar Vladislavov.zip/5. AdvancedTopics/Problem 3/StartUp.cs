﻿namespace Problem_3
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    class StartUp
    {
        static void Main()
        {
            List<string> listNames1 = new List<string>();
            listNames1.Add("Ivan");
            listNames1.Add("Pesho");
            listNames1.Add("Tosho");
            listNames1.Add("Dimitur");
            listNames1.Add("Georgi");

            List<string> listNames2 = new List<string>();
            listNames2.Add("Petur");
            listNames2.Add("Pesho");
            listNames2.Add("Stamat");
            listNames2.Add("Dimitur");
            listNames2.Add("Zoro");

            SortAndCombineLists(listNames1, listNames2);

        }
        public static void SortAndCombineLists(List<string> l1, List<string> l2)
        {
            List<string> withDuples = new List<string>();
            List<string> withoutDuples = new List<string>();

            foreach (string name in l1)
            {
                withDuples.Add(name);
            }

            foreach (string name in l2)
            {
                withDuples.Add(name);
            }

            withDuples.Sort();

            withoutDuples = withDuples.Distinct().ToList();

            foreach (string name in withoutDuples)
            {
                Console.WriteLine(name);
            }
        }

    }
}
