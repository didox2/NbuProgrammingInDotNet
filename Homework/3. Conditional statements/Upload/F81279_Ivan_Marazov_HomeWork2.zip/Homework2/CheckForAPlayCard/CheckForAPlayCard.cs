﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckForAPlayCard
{
    class CheckForAPlayCard
    {
        static void Main(string[] args)
        {
            string cardS = Console.ReadLine();
            int cardN;

            if (cardS == "K" || cardS == "Q" || cardS == "J" || cardS == "A")
            {
                Console.WriteLine("Yes! It's a card!");
            }
            else
            {
                cardN = int.Parse(cardS);
                if (cardN >= 2 && cardN <= 10)
                {
                    Console.WriteLine("Yes! It's a card!");
                }
                else
                {
                    Console.WriteLine("No! This is not a card!");
                }
            }
        }
    }
}
