﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiplicationSign
{
    class MultiplicationSign
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1st Number: ");
            double nr1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("2nd Number: ");
            double nr2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("3rd Number: ");
            double nr3 = Convert.ToDouble(Console.ReadLine());

            if (((nr1 > 0) && (nr2 > 0) && (nr3 > 0)) || ((nr1 < 0) && (nr2 < 0) && (nr3 > 0)) || ((nr1 > 0) && (nr2 < 0) && (nr3 < 0)) || ((nr1 < 0) && (nr2 > 0) && (nr3 < 0)))
            {
                Console.WriteLine("+");
            }
            else if ((nr1 < 0) && (nr2 > 0) && (nr3 > 0) || ((nr1 > 0) && (nr2 < 0) && (nr3 > 0)) || ((nr1 > 0) && (nr2 > 0) && (nr3 < 0)) || ((nr1 < 0) && (nr2 < 0) && (nr3 < 0)))
            {
                Console.WriteLine("-");
            }
            else if ((nr1 == 0) || (nr2 == 0) || (nr3 == 0))
            {
                Console.WriteLine("0");
            }
        }
    }
}
