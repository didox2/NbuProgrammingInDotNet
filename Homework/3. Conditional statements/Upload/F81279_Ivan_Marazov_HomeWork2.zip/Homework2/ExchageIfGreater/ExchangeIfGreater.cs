﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExchageIfGreater
{
    class ExchangeIfGreater
    {
        static void Main(string[] args)
        {
            Console.Write("Number 1:   ");
            double nr1 = double.Parse(Console.ReadLine());
            Console.Write("Number 2:   ");
            double nr2 = double.Parse(Console.ReadLine());
            double temp = 0;

            if (nr1 > nr2)
            {
                temp = nr1;
                nr1 = nr2;
                nr2 = temp;

                Console.WriteLine(nr1 + "  " + nr2);
            }
            else
            {
                Console.WriteLine(nr1 + "  " + nr2);
            }
        }
    }
}
