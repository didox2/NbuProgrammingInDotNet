﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConditionalsHomeWork
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Problem 1: Exchange If Greater");
            Console.WriteLine("Set a value for A and B:");
            Console.Write("a:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.Write("b:");
            int b = Convert.ToInt32(Console.ReadLine());
            if (a > b)
            {
                Console.WriteLine("a  b");
                Console.WriteLine(a + "  " + b);
                int tempA = b;
                int tempB = a;
                a = tempA;
                b = tempB;
                Console.WriteLine("since the value for A you have entered is greater we switch the values:");
                Console.WriteLine("a  b");
                Console.WriteLine(a + "  " + b);
            } else
            {
                Console.WriteLine("a  b");
                Console.WriteLine(a + "  " + b);
            }

            Console.WriteLine("Problem 2: Bonus Score");
            Console.WriteLine("Set a score(1 to 9):");
            Console.Write("Score:");
            int score = Convert.ToInt32(Console.ReadLine());
            if (score >= 1 && score <=3)
            {
                score = score * 10;
                Console.WriteLine("Your score is " + score);
            }else if (score >=4 && score <=6)
            {
                score = score * 100;
                Console.WriteLine("Your score is " + score);
            }
            else if (score >= 7 && score <= 9)
            {
                score = score * 1000;
                Console.WriteLine("Your score is " + score);
            }else
            {
                Console.WriteLine("Invalid Score!");
            }

            Console.WriteLine("Problem 3: Check for a Play Card");
            Console.Write("Write a card and check if it's valid:");
            String playCard = Console.ReadLine();
            if (playCard.Equals("2") || playCard.Equals("3") || playCard.Equals("4") || playCard.Equals("5") || playCard.Equals("6") || playCard.Equals("7") || playCard.Equals("8") || playCard.Equals("9") || playCard.Equals("A") || playCard.Equals("K") || playCard.Equals("J") || playCard.Equals("Q") || playCard.Equals("10"))
            {
                Console.WriteLine(playCard + "  yes");
            }            
            else
            {
                Console.WriteLine(playCard + "  no");
            }

            Console.WriteLine("Problem 4: Multiplication Sign");
            Console.Write("Set A:");
            int mulA = Convert.ToInt32(Console.ReadLine());
            Console.Write("Set B:");
            int mulB = Convert.ToInt32(Console.ReadLine());
            Console.Write("Set C:");
            int mulC = Convert.ToInt32(Console.ReadLine());
            if(mulA ==0 || mulB ==0 || mulC == 0)
            {
                Console.WriteLine("A:" + mulA + " B:" + mulB + " C:" + mulC + " Result: 0");
            }else if ((mulA < 0 && (mulB>0 && mulC > 0)) || (mulB < 0 && (mulA > 0 && mulC > 0)) || (mulC < 0 && (mulA > 0 && mulB > 0)) || (mulB < 0 && mulC < 0 && mulA <0))
            {
                Console.WriteLine("A:" + mulA + " B:" + mulB + " C:" + mulC + " Result: -");
            }else
            {
                Console.WriteLine("A:" + mulA + " B:" + mulB + " C:" + mulC + " Result: +");
            }
            String gg = Console.ReadLine();
        }
    }
}
