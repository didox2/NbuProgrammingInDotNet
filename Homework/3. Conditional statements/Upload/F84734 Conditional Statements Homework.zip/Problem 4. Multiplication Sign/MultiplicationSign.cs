﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_4.Multiplication_Sign
{
    class MultiplicationSign
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number: ");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter another number: ");
            double b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the last number: ");
            double c = Convert.ToDouble(Console.ReadLine());

            if(((a > 0) && (b > 0) && (c > 0)) || ((a < 0) && (b < 0) && (c > 0)) || ((a > 0) && (b < 0) && (c < 0)) || ((a < 0) && (b > 0) && (c < 0)) )
            {
                Console.WriteLine("The result of the multiplication will be +");
            }
            else if((a < 0) && (b > 0) && (c > 0) || ((a > 0) && (b < 0) && (c > 0)) || ((a > 0) && (b > 0) && (c < 0)) || ((a < 0) && (b < 0) && (c < 0)))
            {
                Console.WriteLine("The result of the multiplication will be -");
            }
            else if ((a == 0) || (b == 0) || (c == 0))
            {
                Console.WriteLine("The result of the multiplication will be 0");
            }
        }
    }
}
