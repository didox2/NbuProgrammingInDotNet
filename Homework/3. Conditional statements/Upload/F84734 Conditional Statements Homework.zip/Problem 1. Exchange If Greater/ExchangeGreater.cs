﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conditional_Statements_Homework
{
    class ExchangeGreater
    {
        static void Main(string[] args)
        {
                Console.WriteLine("Please enter a number: ");
                double a = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Please enter another number: ");
                double b = Convert.ToDouble(Console.ReadLine());

                if (a > b)
                {
                    double temp = a;
                    a = b;
                    b = temp;
                    Console.WriteLine(a + " " + b);
                }
                else
                {
                    Console.WriteLine(a + " " + b);
                }
        }
    }
}
