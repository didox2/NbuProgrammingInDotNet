﻿using System;

namespace ExchangeIfGreater
{
    class ExchangeIfGreater
    {
        static void Main(string[] args)
        {
            int a = Int32.Parse(Console.ReadLine());
            int b = Int32.Parse(Console.ReadLine());
            int result = 0;

            if (a > b)
            {
                result = a;
                a = b;
                b = result;
                Console.WriteLine(a + " " + b);
            }
            else
            {
                Console.WriteLine(a + " " + b);
            }
        }
    }
}