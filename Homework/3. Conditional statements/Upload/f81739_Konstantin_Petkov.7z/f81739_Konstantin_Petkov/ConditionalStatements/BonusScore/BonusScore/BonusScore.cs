﻿using System;

namespace BonusScore
{
    class BonusScore
    {
        static void Main(string[] args)
        {
            int a = Int32.Parse(Console.ReadLine());

            if (a > 1 || a < 9)
            {
                if (a == 1 || a == 2 || a == 3)
                {
                    a *= 10;
                    Console.WriteLine(a);
                }
                if (a == 4 || a == 5 || a == 6)
                {
                    a *= 100;
                    Console.WriteLine(a);
                }
                if (a == 7 || a == 8 || a == 9)
                {
                    a *= 1000;
                    Console.WriteLine(a);
                }
            }
            else
            {
                Console.WriteLine("invalid score");
            }

        }
    }
}