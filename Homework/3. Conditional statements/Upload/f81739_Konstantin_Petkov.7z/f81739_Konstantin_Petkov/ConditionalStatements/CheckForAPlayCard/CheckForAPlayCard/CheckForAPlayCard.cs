﻿using System;

namespace CheckForAPlayCard
{
    class CheckForAPlayCard
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();


            if (str == "J" || str == "Q" || str == "A" || str == "K")
            {
                Console.WriteLine("yes");
            }
            else
            {
                int a = int.Parse(str);
                if (a >= 2 && a <= 10)
                {
                    Console.WriteLine("yes");
                }
                else
                {
                    Console.WriteLine("no");
                }
            }
        }                
    }
}