﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BonusScore
{
    class Problem2
    {
        static void Main(string[] args)
        {
            Console.Write("Chose score between 1 - 9: ");
            int score = int.Parse(Console.ReadLine());
            if (score < 1 || score > 9)
            {
                Console.WriteLine("invalid score");
            }
            else
            {
                if (score == 1 || score == 2 || score == 3)
                {
                    score *= 10;
                    Console.WriteLine(score);
                }
                if (score == 4 || score == 5 || score == 6)
                {
                    score *= 100;
                    Console.WriteLine(score);
                }
                if (score == 7 || score == 8 || score == 9)
                {
                    score *= 1000;
                    Console.WriteLine(score);
                }
            }
          
        }
    }
}
