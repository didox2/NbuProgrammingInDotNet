﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExchangeIfGreater
{
    class Problem1
    {
        static void Main(string[] args)
        {       
            Console.Write("Enter A: ");
            double a = double.Parse(Console.ReadLine());
            Console.Write("Enter B: ");
            double b = double.Parse(Console.ReadLine());
            double c = 0;
            if (a > b)
            {
                c = a;
                a = b;
                b = c;
                Console.WriteLine(a+" "+b);
            }
            else
            {
                Console.WriteLine(a+" "+b);
            }
        }
    }
}
