﻿using System;

class ExchangeIfGreater
{
    static void Main()
    {
        double a;
        double b;
        Console.WriteLine("Enter two numbers:");
         a = double.Parse(Console.ReadLine());
         b = double.Parse(Console.ReadLine());
        if (a > b)
        {
            Console.WriteLine("{0} {1}", b, a);
        }
        else
        {
            Console.WriteLine("{0} {1}", a, b);
        }
        Console.ReadKey();
    }
}
