﻿using System;

class MultiplicationSign
{
    static void Main()
    {
        string x;
        Console.WriteLine("Enter integers a,b and c:");
        double a = double.Parse(Console.ReadLine()); 
        double b = double.Parse(Console.ReadLine());
        double c = double.Parse(Console.ReadLine());
        
        if (a > 0 && b > 0 && c > 0 || a < 0 && b < 0 && c > 0 || a > 0 && b < 0 && c < 0 ||
            a < 0 && b > 0 && c < 0)
        {
            x = "+";
        }
        else if (a < 0 && b > 0 && c > 0 || a > 0 && b < 0 && c > 0 || a > 0 && b > 0 && c < 0 ||
            a < 0 && b < 0 && c < 0)
        {
            x = "-";
        }
        else
        {
            x = "0";

       }
        Console.WriteLine("The result is:" +"  " + x);
        

        Console.ReadKey();
    }

}


